﻿using System;

namespace Examples {
    public class GenericClass {

    }
}
