﻿using UnityEngine;

public class ConstructorExample2 : Transform {
    [SerializeField] private int nrOfLives = 3;
    [SerializeField] private int otherInteger = 3;
}
